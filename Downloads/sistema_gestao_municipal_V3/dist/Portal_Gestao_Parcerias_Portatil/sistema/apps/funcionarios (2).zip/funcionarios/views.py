import io
from django.contrib.auth.models import User
from django.urls import reverse_lazy
from django.views.generic import (
    ListView,
    UpdateView,
    DeleteView,
    CreateView
)
from django.views.generic.base import View, TemplateView
from reportlab.pdfgen import canvas
from django.http import HttpResponse
from django.template.loader import get_template
import xhtml2pdf.pisa as pisa
from .models import Funcionario
from django.utils.translation import gettext as _
from django.core.paginator import Paginator
from django.shortcuts import render
# from funcionarios.models import Funcionario

class FuncionariosList(ListView):
    model = Funcionario

    # paginate_by = 15  # if pagination is desired

    def listing(request):
        funcionarios_list = Funcionario.objects.all()
        paginator = Paginator(funcionarios_list, 10)  # Show 25 contacts per page.

        page_number = request.GET.get('page')
        page_obj = paginator.get_page(page_number)
        return render(request, 'funcionario_list.html', {'page_obj': page_obj})

    def get_queryset(self):
        empresa_logada = self.request.user.funcionario.empresa
        return Funcionario.objects.filter(empresa=empresa_logada)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['report_button'] = _("Employee report")
        return context


class FuncionarioEdit(UpdateView):
    model = Funcionario
    fields = ['nome', 'usuario', 'cargo', 'nivel', 'equipamento', 'endereco', 'bairro', 'cep', 'cidade',
                   'estado', 'email', 'Telefone', 'de_ferias', 'ativo', 'salarioBase', 'salarioBruto', 'salarioLiquido',
                   'diasTrabalhados', 'avisoPrevio', 'avosFerias', 'avosTercoFerias', 'avos13Salario', 'fgts',
                   'multafgts', 'inss', 'totalVerbaRescisoria', 'totalRescisao', 'conferencia3'
              ]

    success_url = reverse_lazy('list_funcionarios')


class FuncionarioDelete(DeleteView):
    model = Funcionario
    success_url = reverse_lazy('list_funcionarios')


class FuncionarioCreate(CreateView):
    model = Funcionario
    fields = ['nome', 'usuario', 'cargo', 'nivel', 'equipamento', 'endereco', 'bairro', 'cep', 'cidade',
                   'estado', 'email', 'Telefone', 'de_ferias', 'ativo', 'salarioBase', 'salarioBruto', 'salarioLiquido',
                   'diasTrabalhados', 'avisoPrevio', 'avosFerias', 'avosTercoFerias', 'avos13Salario', 'fgts',
                   'multafgts', 'inss', 'totalVerbaRescisoria', 'totalRescisao', 'conferencia3'
              ]

    success_url = reverse_lazy('list_funcionarios')

    def form_valid(self, form):
        funcionario = form.save(commit=False)
        username = funcionario.usuario.split(' ')[0]
        funcionario.empresa = self.request.user.funcionario.empresa
        funcionario.user = User.objects.create(username=username)
        funcionario.save()
        return super(FuncionarioCreate, self).form_valid(form)


def relatorio_funcionario(request):  # feito com reportlab
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="Relatório de Funcionários.pdf"'

    buffer = io.BytesIO()
    p = canvas.Canvas(buffer)

    p.drawString(200, 810, 'Relatorio de funcionarios')

    funcionarios = Funcionario.objects.filter(
        empresa=request.user.funcionario.empresa)

    str_ = 'Nome: %s | Hora Extra: %.2f'

    p.drawString(0, 800, '_' * 150)

    y = 750
    for funcionario in funcionarios:
        p.drawString(10, y, str_ % (
            funcionario.nome, funcionario.total_horas_extra))
        y -= 20

    p.showPage()
    p.save()

    pdf = buffer.getvalue()
    buffer.close()
    response.write(pdf)

    return response


class Render:
    @staticmethod
    def render(path: str, params: dict, filename: str):
        template = get_template(path)
        html = template.render(params)
        response = io.BytesIO()
        pdf = pisa.pisaDocument(
            io.BytesIO(html.encode("UTF-8")), response)
        if not pdf.err:
            response = HttpResponse(
                response.getvalue(), content_type='application/pdf')
            response['Content-Disposition'] = 'attachment;filename=%s.pdf' % filename
            return response
        else:
            return HttpResponse("Error Rendering PDF", status=400)


class Pdf(View):

    def get(self, request):
        params = {
            'today': 'Variavel today',
            'sales': 'Variavel sales',
            'request': request,
        }
        return Render.render('funcionarios/relatorio.html', params, 'Relatório de Funcionários')


class PdfDebug(TemplateView):
    template_name = 'funcionarios/relatorio.html'
