from django.forms import ModelForm
from .models import Funcionario


class FuncionarioForm(ModelForm):
    class Meta:
        model = Funcionario
        fields = ['nome', 'usuario', 'cargo', 'nivel', 'equipamento', 'endereco', 'bairro', 'cep', 'cidade', 'estado',
                  'email', 'Telefone', 'de_ferias', 'ativo', 'salarioBase', 'salarioBruto', 'salarioLiquido', 'diasTrabalhados',
                  'avisoPrevio', 'avosFerias', 'avosTercoFerias', 'avos13Salario', 'fgts', 'multafgts', 'inss',
                  'totalVerbaRescisoria', 'totalRescisao', 'curso', 'conferencia3'
                  ]
